public class GorillaCTFManager : GorillaGameManager
{
}
